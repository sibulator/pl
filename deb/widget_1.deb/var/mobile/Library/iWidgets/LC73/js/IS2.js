
function init() {
updateIS2data();

    setInterval(updateIS2data, 15000);
}

function updateIS2data(){
	
//Signal Strength//
if (WifiOn() == true){
document.getElementById("WifiImage").src="Images/Signals/Wifi" + WifiSignal() + ".png";
}else{
document.getElementById("WifiImage").src = "Images/Signals/NoWifi.png";
}


//Cellular Strength//
if (airplaneMode() == true){
document.getElementById("CellImage").src="Images/Signals/NoCell.png";
}else{
document.getElementById("CellImage").src="Images/Signals/Cell" + getSignal() + ".png";
}


//Battery Percent//
document.getElementById("battLevel").innerHTML = getBatteryPercent() + "%";  


//Battery Image//
var Level = getBatteryPercent(), batteryImage;

if( Level > 0  && Level <= 2 )	batteryImage="Images/Battery/BatteryBG_1@2x.png";
if( Level > 2  && Level <= 5 )	batteryImage="Images/Battery/BatteryBG_2@2x.png";
if( Level > 5  && Level <= 10 ) batteryImage="Images/Battery/BatteryBG_3@2x.png";
if( Level > 10 && Level <= 20 ) batteryImage="Images/Battery/BatteryBG_4@2x.png";
if( Level > 20 && Level <= 25 ) batteryImage="Images/Battery/BatteryBG_5@2x.png";
if( Level > 25 && Level <= 35 ) batteryImage="Images/Battery/BatteryBG_6@2x.png";
if( Level > 35 && Level <= 45 ) batteryImage="Images/Battery/BatteryBG_7@2x.png";
if( Level > 45 && Level <= 50 ) batteryImage="Images/Battery/BatteryBG_8@2x.png";
if( Level > 50 && Level <= 55 ) batteryImage="Images/Battery/BatteryBG_9@2x.png";
if( Level > 55 && Level <= 65 ) batteryImage="Images/Battery/BatteryBG_10@2x.png";
if( Level > 65 && Level <= 70 ) batteryImage="Images/Battery/BatteryBG_11@2x.png";
if( Level > 70 && Level <= 80 ) batteryImage="Images/Battery/BatteryBG_12@2x.png";
if( Level > 80 && Level <= 85 ) batteryImage="Images/Battery/BatteryBG_13@2x.png";
if( Level > 85 && Level <= 90 ) batteryImage="Images/Battery/BatteryBG_14@2x.png";
if( Level > 90 && Level <= 95 ) batteryImage="Images/Battery/BatteryBG_15@2x.png";
if( Level > 95 && Level <= 98 ) batteryImage="Images/Battery/BatteryBG_16@2x.png";
if( Level > 98 && Level <= 100 ) batteryImage="Images/Battery/BatteryBG_17@2x.png";

document.getElementById("BatteryImage").src=batteryImage;


//Battery State//
if (getBatteryState() == 1){
document.getElementById("battState").innerHTML = discharging;
document.getElementById("battState").style.color = "#fff";
}else{
document.getElementById("battState").innerHTML = charging;
document.getElementById("battState").style.color = "#fff";
}


//RAM Stats//
document.getElementById("freeRam").innerHTML = getRam() + "MB" + " " + " "; 


//RAM Image//

var Fram = getRam(), framImage;
if( Fram > 0  && Fram <= 50 )  framImage="Images/RamFree/R1.png";
if( Fram > 50  && Fram <= 100 )  framImage="Images/RamFree/R2.png";
if( Fram > 100 && Fram <= 150 )  framImage="Images/RamFree/R3.png";
if( Fram > 150 && Fram <= 200 ) framImage="Images/RamFree/R4.png";
if( Fram > 200 && Fram <= 250 ) framImage="Images/RamFree/R5.png";
if( Fram > 250 && Fram <= 300 ) framImage="Images/RamFree/R6.png";
if( Fram > 300 && Fram <= 350 ) framImage="Images/RamFree/R7.png";
if( Fram > 350 && Fram <= 400 ) framImage="Images/RamFree/R8.png";
if( Fram > 400 && Fram <= 450 ) framImage="Images/RamFree/R9.png";
if( Fram > 450 && Fram <= 500 ) framImage="Images/RamFree/R10.png";
if( Fram > 500 && Fram <= 550 ) framImage="Images/RamFree/R11.png";
if( Fram > 550 && Fram <= 600 ) framImage="Images/RamFree/R12.png";
if( Fram > 600 && Fram <= 650 ) framImage="Images/RamFree/R13.png";
if( Fram > 650 && Fram <= 700 ) framImage="Images/RamFree/R14.png";
if( Fram > 700 && Fram <= 750 ) framImage="Images/RamFree/R15.png";

document.getElementById("FramImage").src=framImage;

//devicename//
document.getElementById("dName").innerHTML = deviceName();

}

