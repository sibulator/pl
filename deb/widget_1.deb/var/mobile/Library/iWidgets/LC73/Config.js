
 //Scripts by JunesiPhone,

var twentyfour = true;
var padzero = true;
var refresh = 5000;

var weathercode = 'NLXX0038';
var celsius = true;
var gpsswitch = true; //must use widget weather xml if set to true
var refreshrate = 10;

var language = "en"; // en, cz, it, sp, de, fr, zh 


